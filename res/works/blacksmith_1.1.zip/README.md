# Army BlackSmith

### Lore

Circa middle ages, you're a blacksmith in a small village and your role is to assist the village's protection by calling upon the deities's blessing.
You will forge weapons which you can then give as offering to the gods, and they'll protect your village.
But you'll need resources to do that.

You will frequently be robbed by invaders, so beware.

### How to run

Run the armyBlacksmith.exe
To quit the game, press ALT+F4


### How to play

Army Blacksmith is a rhythm and action/management game.
The game sequence is :

1) Buy resources from the top of your screen
2) Select a weapon and forge it -- it plays as a rhythm sequence. Use YHGJ to input notes
3) The weapon cools down
4) When it's cold, you can choose to sell it or give it as offering

The goal of the game is to give offerings until the offering bar reaches 100%

-----------------------------------------

### In-depth

> Based on your accuracy during the rhythm sequence, the weapon's value goes from 50% to 200% of the price of its ingredients.
> You have 3 anvils. You can't use one to forge when a weapon is cooling down on it.
> An ingredient's price increases on each unit bought (inflation). It lowers back over time
> Your workshop will be robbed every 30 seconds, stealing some of your money (can become negative).
	> The robberies' impact increases exponentially over time
	> Offering weapons to the gods pushes back that impact based on the offering's worth
	> You can consider the game over if you can't buy or forge anymore due to insuficcient money


### Changelog

- v1.1 (29/12/2020)

	> Added an easy mode, with less mathematically increasing attacks and beat sequences with only half inputs	
	> Repositionned lateral anvils and the key input 	
	> Fixed ore menu's hotkey so it works with both Numpad and NumKeys


### Credits

> Sprite work
	> All sprites are taken from Dofus 1.29, Insaniquarium Deluxe and Atomica Deluxe
	> Game background by Henry Chervenka https://www.zbrushcentral.com/t/blacksmith-workshop/209686#post1236263
	
> Audio
	> Sound effects from Insaniquarium Deluxe and Mega Man Zero ZX
	> Victory theme from Final Fantasy
